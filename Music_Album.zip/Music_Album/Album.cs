﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Music_Album
{
    public class Album
    {
        /// <summary>
        /// Titel ein Album
        /// </summary>
        public string AlbumsTitel;

        /// <summary>
        /// Eine Liste mit Songs.
        /// </summary>
        public List<Song> SongList;

        /// <summary>
        /// Konstruktor mit Parametern Name und Künstler.
        /// </summary>
        /// <param name="name"></param>
        /// <param name="kuenstler"></param>
        public Album(string name)
        {
            SongList = new List<Song>();
            AlbumsTitel = name;
        }
    }
}
