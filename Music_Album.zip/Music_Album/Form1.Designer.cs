﻿namespace Music_Album
{
    partial class Form1
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form1));
            lbl_Begriff = new Label();
            lbl_kuenstler = new Label();
            lbl_herkunft = new Label();
            lbl_album = new Label();
            lbl_song = new Label();
            lbl_dauer = new Label();
            pictureBox1 = new PictureBox();
            txtbox_Kuenstler = new TextBox();
            txtbox_Dauer = new TextBox();
            txtbox_Song = new TextBox();
            txtbox_Album = new TextBox();
            txtbox_Herkunftsland = new TextBox();
            checkBox1 = new CheckBox();
            btn_speichern = new Button();
            listBox1_kuenstler = new ListBox();
            listBox2_album = new ListBox();
            lbl_kuenstler_Anzeiger = new Label();
            lbl_album_Anzeiger = new Label();
            btn_Aktualisieren = new Button();
            btn_Beenden = new Button();
            listBox3_song = new ListBox();
            lbl_song_Anzeiger = new Label();
            ((System.ComponentModel.ISupportInitialize)pictureBox1).BeginInit();
            SuspendLayout();
            // 
            // lbl_Begriff
            // 
            lbl_Begriff.AutoSize = true;
            lbl_Begriff.BackColor = Color.FromArgb(0, 192, 0);
            lbl_Begriff.Font = new Font("Sylfaen", 18F, FontStyle.Regular, GraphicsUnit.Point, 0);
            lbl_Begriff.ForeColor = SystemColors.ActiveCaptionText;
            lbl_Begriff.Location = new Point(363, 18);
            lbl_Begriff.Name = "lbl_Begriff";
            lbl_Begriff.Size = new Size(84, 31);
            lbl_Begriff.TabIndex = 0;
            lbl_Begriff.Text = "Musify";
            // 
            // lbl_kuenstler
            // 
            lbl_kuenstler.AutoSize = true;
            lbl_kuenstler.Location = new Point(26, 78);
            lbl_kuenstler.Name = "lbl_kuenstler";
            lbl_kuenstler.Size = new Size(56, 15);
            lbl_kuenstler.TabIndex = 1;
            lbl_kuenstler.Text = "Künstler :";
            // 
            // lbl_herkunft
            // 
            lbl_herkunft.AutoSize = true;
            lbl_herkunft.Location = new Point(26, 112);
            lbl_herkunft.Name = "lbl_herkunft";
            lbl_herkunft.Size = new Size(88, 15);
            lbl_herkunft.TabIndex = 2;
            lbl_herkunft.Text = "Herkunftsland :";
            // 
            // lbl_album
            // 
            lbl_album.AutoSize = true;
            lbl_album.Location = new Point(26, 146);
            lbl_album.Name = "lbl_album";
            lbl_album.Size = new Size(49, 15);
            lbl_album.TabIndex = 3;
            lbl_album.Text = "Album :";
            // 
            // lbl_song
            // 
            lbl_song.AutoSize = true;
            lbl_song.Location = new Point(26, 185);
            lbl_song.Name = "lbl_song";
            lbl_song.Size = new Size(40, 15);
            lbl_song.TabIndex = 4;
            lbl_song.Text = "Song :";
            // 
            // lbl_dauer
            // 
            lbl_dauer.AutoSize = true;
            lbl_dauer.Location = new Point(26, 218);
            lbl_dauer.Name = "lbl_dauer";
            lbl_dauer.Size = new Size(44, 15);
            lbl_dauer.TabIndex = 5;
            lbl_dauer.Text = "Dauer :";
            // 
            // pictureBox1
            // 
            pictureBox1.BackColor = SystemColors.ButtonHighlight;
            pictureBox1.BackgroundImageLayout = ImageLayout.None;
            pictureBox1.Image = (Image)resources.GetObject("pictureBox1.Image");
            pictureBox1.Location = new Point(328, 12);
            pictureBox1.Name = "pictureBox1";
            pictureBox1.Size = new Size(42, 42);
            pictureBox1.SizeMode = PictureBoxSizeMode.AutoSize;
            pictureBox1.TabIndex = 6;
            pictureBox1.TabStop = false;
            pictureBox1.Click += pictureBox1_Click;
            // 
            // txtbox_Kuenstler
            // 
            txtbox_Kuenstler.Location = new Point(134, 75);
            txtbox_Kuenstler.Name = "txtbox_Kuenstler";
            txtbox_Kuenstler.Size = new Size(152, 23);
            txtbox_Kuenstler.TabIndex = 7;
            txtbox_Kuenstler.TextChanged += txtbox_Kuenstler_TextChanged;
            // 
            // txtbox_Dauer
            // 
            txtbox_Dauer.Location = new Point(134, 215);
            txtbox_Dauer.Name = "txtbox_Dauer";
            txtbox_Dauer.Size = new Size(152, 23);
            txtbox_Dauer.TabIndex = 8;
            txtbox_Dauer.TextChanged += txtbox_Dauer_TextChanged;
            // 
            // txtbox_Song
            // 
            txtbox_Song.Location = new Point(134, 182);
            txtbox_Song.Name = "txtbox_Song";
            txtbox_Song.Size = new Size(152, 23);
            txtbox_Song.TabIndex = 9;
            txtbox_Song.TextChanged += txtbox_Song_TextChanged;
            // 
            // txtbox_Album
            // 
            txtbox_Album.Location = new Point(134, 143);
            txtbox_Album.Name = "txtbox_Album";
            txtbox_Album.Size = new Size(152, 23);
            txtbox_Album.TabIndex = 10;
            txtbox_Album.TextChanged += txtbox_Album_TextChanged;
            // 
            // txtbox_Herkunftsland
            // 
            txtbox_Herkunftsland.Location = new Point(134, 109);
            txtbox_Herkunftsland.Name = "txtbox_Herkunftsland";
            txtbox_Herkunftsland.Size = new Size(152, 23);
            txtbox_Herkunftsland.TabIndex = 11;
            txtbox_Herkunftsland.TextChanged += txtbox_Herkunftsland_TextChanged;
            // 
            // checkBox1
            // 
            checkBox1.AutoSize = true;
            checkBox1.BackColor = Color.White;
            checkBox1.Location = new Point(26, 258);
            checkBox1.Name = "checkBox1";
            checkBox1.Size = new Size(83, 19);
            checkBox1.TabIndex = 12;
            checkBox1.Text = "checkBox1";
            checkBox1.UseVisualStyleBackColor = false;
            checkBox1.CheckedChanged += checkBox1_CheckedChanged;
            // 
            // btn_speichern
            // 
            btn_speichern.BackColor = Color.FromArgb(0, 192, 0);
            btn_speichern.ForeColor = SystemColors.ActiveCaptionText;
            btn_speichern.Location = new Point(30, 482);
            btn_speichern.Name = "btn_speichern";
            btn_speichern.Size = new Size(84, 34);
            btn_speichern.TabIndex = 13;
            btn_speichern.Text = "Speichern";
            btn_speichern.UseVisualStyleBackColor = false;
            btn_speichern.Click += btn_speichern_Click;
            // 
            // listBox1_kuenstler
            // 
            listBox1_kuenstler.FormattingEnabled = true;
            listBox1_kuenstler.ItemHeight = 15;
            listBox1_kuenstler.Location = new Point(328, 91);
            listBox1_kuenstler.Name = "listBox1_kuenstler";
            listBox1_kuenstler.Size = new Size(186, 169);
            listBox1_kuenstler.TabIndex = 14;
            listBox1_kuenstler.SelectedIndexChanged += listBox1_kuenstler_SelectedIndexChanged;
            // 
            // listBox2_album
            // 
            listBox2_album.FormattingEnabled = true;
            listBox2_album.ItemHeight = 15;
            listBox2_album.Location = new Point(565, 91);
            listBox2_album.Name = "listBox2_album";
            listBox2_album.Size = new Size(186, 169);
            listBox2_album.TabIndex = 15;
            listBox2_album.SelectedIndexChanged += listBox2_album_SelectedIndexChanged;
            // 
            // lbl_kuenstler_Anzeiger
            // 
            lbl_kuenstler_Anzeiger.AutoSize = true;
            lbl_kuenstler_Anzeiger.Location = new Point(328, 73);
            lbl_kuenstler_Anzeiger.Name = "lbl_kuenstler_Anzeiger";
            lbl_kuenstler_Anzeiger.Size = new Size(56, 15);
            lbl_kuenstler_Anzeiger.TabIndex = 16;
            lbl_kuenstler_Anzeiger.Text = "Kuenstler";
            // 
            // lbl_album_Anzeiger
            // 
            lbl_album_Anzeiger.AutoSize = true;
            lbl_album_Anzeiger.Location = new Point(565, 73);
            lbl_album_Anzeiger.Name = "lbl_album_Anzeiger";
            lbl_album_Anzeiger.Size = new Size(43, 15);
            lbl_album_Anzeiger.TabIndex = 17;
            lbl_album_Anzeiger.Text = "Album";
            // 
            // btn_Aktualisieren
            // 
            btn_Aktualisieren.BackColor = Color.FromArgb(0, 192, 0);
            btn_Aktualisieren.ForeColor = SystemColors.ActiveCaptionText;
            btn_Aktualisieren.Location = new Point(134, 482);
            btn_Aktualisieren.Name = "btn_Aktualisieren";
            btn_Aktualisieren.Size = new Size(84, 34);
            btn_Aktualisieren.TabIndex = 18;
            btn_Aktualisieren.Text = "Aktualisieren";
            btn_Aktualisieren.UseVisualStyleBackColor = false;
            // 
            // btn_Beenden
            // 
            btn_Beenden.BackColor = Color.FromArgb(0, 192, 0);
            btn_Beenden.ForeColor = SystemColors.ActiveCaptionText;
            btn_Beenden.Location = new Point(937, 482);
            btn_Beenden.Name = "btn_Beenden";
            btn_Beenden.Size = new Size(84, 34);
            btn_Beenden.TabIndex = 19;
            btn_Beenden.Text = "Beenden";
            btn_Beenden.UseVisualStyleBackColor = false;
            // 
            // listBox3_song
            // 
            listBox3_song.FormattingEnabled = true;
            listBox3_song.ItemHeight = 15;
            listBox3_song.Location = new Point(812, 91);
            listBox3_song.Name = "listBox3_song";
            listBox3_song.Size = new Size(186, 169);
            listBox3_song.TabIndex = 20;
            // 
            // lbl_song_Anzeiger
            // 
            lbl_song_Anzeiger.AutoSize = true;
            lbl_song_Anzeiger.Location = new Point(812, 73);
            lbl_song_Anzeiger.Name = "lbl_song_Anzeiger";
            lbl_song_Anzeiger.Size = new Size(43, 15);
            lbl_song_Anzeiger.TabIndex = 21;
            lbl_song_Anzeiger.Text = "Album";
            // 
            // Form1
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            BackColor = SystemColors.ControlLightLight;
            ClientSize = new Size(1046, 539);
            Controls.Add(lbl_song_Anzeiger);
            Controls.Add(listBox3_song);
            Controls.Add(btn_Beenden);
            Controls.Add(btn_Aktualisieren);
            Controls.Add(lbl_album_Anzeiger);
            Controls.Add(lbl_kuenstler_Anzeiger);
            Controls.Add(listBox2_album);
            Controls.Add(listBox1_kuenstler);
            Controls.Add(btn_speichern);
            Controls.Add(checkBox1);
            Controls.Add(txtbox_Herkunftsland);
            Controls.Add(txtbox_Album);
            Controls.Add(txtbox_Song);
            Controls.Add(txtbox_Dauer);
            Controls.Add(txtbox_Kuenstler);
            Controls.Add(lbl_Begriff);
            Controls.Add(pictureBox1);
            Controls.Add(lbl_dauer);
            Controls.Add(lbl_song);
            Controls.Add(lbl_album);
            Controls.Add(lbl_herkunft);
            Controls.Add(lbl_kuenstler);
            Name = "Form1";
            Text = "Form1";
            ((System.ComponentModel.ISupportInitialize)pictureBox1).EndInit();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Label lbl_Begriff;
        private Label lbl_kuenstler;
        private Label lbl_herkunft;
        private Label lbl_album;
        private Label lbl_song;
        private Label lbl_dauer;
        private PictureBox pictureBox1;
        private TextBox txtbox_Kuenstler;
        private TextBox txtbox_Dauer;
        private TextBox txtbox_Song;
        private TextBox txtbox_Album;
        private TextBox txtbox_Herkunftsland;
        private CheckBox checkBox1;
        private Button btn_speichern;
        private ListBox listBox1_kuenstler;
        private ListBox listBox2_album;
        private Label lbl_kuenstler_Anzeiger;
        private Label lbl_album_Anzeiger;
        private Button btn_Aktualisieren;
        private Button btn_Beenden;
        private ListBox listBox3_song;
        private Label lbl_song_Anzeiger;
    }
}
