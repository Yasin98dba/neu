namespace Music_Album
{
    public partial class Form1 : Form
    {
        public KuenstlerList kuenstler_LIST;

        public Kuenstler kuenstler;
        public Form1()
        {
            InitializeComponent();
            AnfangsAblauf();
            kuenstler_LIST = new KuenstlerList();
        }
        private void AnfangsAblauf()
        {
            btn_Aktualisieren.Enabled = false;
            btn_speichern.Enabled = true;
        }

        private void pictureBox1_Click(object sender, EventArgs e)
        {

        }

        private void checkBox1_CheckedChanged(object sender, EventArgs e)
        {
            if (checkBox1.Checked)
            {
                lbl_herkunft.Enabled = false;
                lbl_kuenstler.Enabled = false;
                lbl_album.Enabled = false;
                txtbox_Kuenstler.Enabled = false;
                txtbox_Herkunftsland.Enabled = false;
                txtbox_Album.Enabled = false;
            }
            else
            {
                lbl_album.Enabled = true;
                lbl_herkunft.Enabled = true;
                lbl_kuenstler.Enabled = true;
                txtbox_Kuenstler.Enabled = true;
                txtbox_Herkunftsland.Enabled = true;
                txtbox_Album.Enabled = true;
            }
        }

        private void btn_speichern_Click(object sender, EventArgs e)
        {
            kuenstler = new Kuenstler(txtbox_Kuenstler.Text, txtbox_Herkunftsland.Text);
            kuenstler.AlbumList.Add(new Album(txtbox_Album.Text));
            listBox1_kuenstler.Items.Clear();

            kuenstler_LIST.kuenstlerlist.Add(kuenstler);
            foreach (Kuenstler kuenstler1 in kuenstler_LIST.kuenstlerlist)
            {
                listBox1_kuenstler.Items.Add(kuenstler1.Name);
            }
        }

        private void txtbox_Kuenstler_TextChanged(object sender, EventArgs e)
        {

        }

        private void txtbox_Herkunftsland_TextChanged(object sender, EventArgs e)
        {

        }

        private void txtbox_Album_TextChanged(object sender, EventArgs e)
        {

        }

        private void txtbox_Song_TextChanged(object sender, EventArgs e)
        {

        }

        private void txtbox_Dauer_TextChanged(object sender, EventArgs e)
        {
            //if (txtbox_Dauer.Text == "" || txtbox_Song.Text == "" || txtbox_Album.Text == "" || txtbox_Herkunftsland.Text == "" || txtbox_Kuenstler.Text == "")
            //{
            //    btn_speichern.Enabled = true;
            //}
        }

        private void listBox1_kuenstler_SelectedIndexChanged(object sender, EventArgs e)
        {
            GetSelectedKuenstler();
        }

        public void GetSelectedKuenstler()
        {
            if (kuenstler_LIST.kuenstlerlist[listBox1_kuenstler.SelectedIndex] == null)
            {
                return;
            }
            listBox2_album.Items.Clear();
            kuenstler = kuenstler_LIST.kuenstlerlist[listBox1_kuenstler.SelectedIndex];
            foreach (Album album in kuenstler.AlbumList)
            {
                listBox2_album.Items.Add(album.AlbumsTitel);
            }
        }

        private void listBox2_album_SelectedIndexChanged(object sender, EventArgs e)
        {
            GetSelectedAlbum();
        }

        public void GetSelectedAlbum()
        {
            if (kuenstler_LIST.kuenstlerlist[listBox1_kuenstler.SelectedIndex] == null)
            {
                return;
            }
            listBox2_album.Items.Clear();
            kuenstler = kuenstler_LIST.kuenstlerlist[listBox1_kuenstler.SelectedIndex];
            foreach (Album album in kuenstler.AlbumList)
            {
                listBox2_album.Items.Add(album.AlbumsTitel);
            }
        }

    }
}
