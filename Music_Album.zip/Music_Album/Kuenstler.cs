﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Music_Album
{
    public class Kuenstler
    {
        /// <summary>
        /// Name der Kuenstler.
        /// </summary>
        public string Name;

        /// <summary>
        /// Herkunftsland des Kuenstlers.
        /// </summary>
        public string Herkunfstland;

        public List<Album> AlbumList =new List<Album>();

        /// <summary>
        /// Konstruktor mit Parametern Name und Herkunftsland.
        /// </summary>
        /// <param name="name"></param>
        /// <param name="herkunfstland"></param>
        public Kuenstler (string name, string herkunfstland)
        {
            Name = name;
            Herkunfstland = herkunfstland;
        }
    }
}
