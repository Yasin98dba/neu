﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Music_Album
{
    public class Song
    {
        /// <summary>
        /// Titel des Song.
        /// </summary>
        public string SongTitel;

        /// <summary>
        /// Dauer des Song.
        /// </summary>
        public string SongDauer;

        /// <summary>
        /// Konstruktor  Parametern Songtitel und Songdauer.
        /// </summary>
        /// <param name="songTitel"></param>
        /// <param name="songDauer"></param>
        public Song(string songTitel, string songDauer)
        {
            SongTitel = songTitel;
            SongDauer = songDauer;
        }
    }
}
